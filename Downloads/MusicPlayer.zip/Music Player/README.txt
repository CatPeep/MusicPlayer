To play your music, just put music files inside of the "music" folder and run Music Player.exe
Have fun!

Created by CatPeep#7048

Only mp3 and wav files are supported

If songs won't play try deleting lastsong.txt

!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
IF SOMEONE HAS SOLD THIS PROGRAM TO YOU, PLEASE REPORT THEM.
THIS PROGRAM IS FREE AND NOT TO BE SOLD.
!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

Key Binds:

Pause/Play       || End key
Previous Song    || Numpad 4 key
Next Song        || Numpad 6 key
Add/Remove Songs || Insert key

(You can't change the keybinds.)
